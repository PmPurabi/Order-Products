package com.example.Product.Service;

import com.example.Product.DTO.OrderInputDto;
import com.example.Product.DTO.ProductDto;
import com.example.Product.Entity.Orders;
import com.example.Product.Entity.Products;
import com.example.Product.Entity.User;
import com.example.Product.Exception.ProductNotFoundException;
import com.example.Product.Exception.UserNoFoundException;
import com.example.Product.Mapper.OrderMapper;
import com.example.Product.Repository.OrderRepo;
import com.example.Product.Repository.ProductRepo;
import com.example.Product.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    OrderRepo orderRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    ProductRepo productRepo;
    Products products;

    ProductDto productDto;

    @Override
    public OrderInputDto createOrder(OrderInputDto orderDto) {
        Orders orders = OrderMapper.mapToOrder(orderDto);

        Optional<User> user = userRepo.findById(orderDto.getUserId());
        List<Integer> validUserIds = new ArrayList<>();
        while(user.isPresent())
        {
            validUserIds.add(user.get().getUserId());
        }// storing all the userIds from DB

        for(Integer userId : validUserIds)
        {
            if (!(validUserIds.contains(userId)))
            {
                throw new UserNoFoundException("User not found ");
            }
        }
        List<Products> products = productRepo.findByProductIdIn(orderDto.getProductId());
        List<Integer> validProductIds =new ArrayList<>();
        for(Products product : products){
            validProductIds.add(product.productId);
        }
        for (Integer productsId : orderDto.getProductId())
        {
            if (!validProductIds.contains(productsId))
                throw new ProductNotFoundException("Product not found !", orderDto.getProductId());
        }// for ends
        orders.setOrderId(orders.getUserId());
        orders.setProductId(orderDto.getProductId());
        Orders saveOrder = orderRepo.save(orders);
        OrderInputDto saveOrderDto;
        saveOrderDto = OrderMapper.mapToDto(saveOrder);

        return saveOrderDto;
    }
    @Override
    public OrderInputDto getOrder(int OrderId)
    {
        Optional<Orders> order = orderRepo.findById(Long.valueOf(OrderId));
        return OrderMapper.mapToDto(order.get());

    }
}






