package com.example.Product.Service;

import com.example.Product.DTO.UserDto;
import com.example.Product.Entity.User;

public interface UserService {
    public UserDto createUser(UserDto userDto);
    public UserDto getUser(int userID);
}
