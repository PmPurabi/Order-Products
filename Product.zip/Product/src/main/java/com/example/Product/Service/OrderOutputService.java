package com.example.Product.Service;
import com.example.Product.DTO.OrderOutputDto;
import com.example.Product.DTO.ProductDto;
import com.example.Product.DTO.UserDto;

import java.util.List;

public interface OrderOutputService {

    public OrderOutputDto getOrderId(int orderId);
}
