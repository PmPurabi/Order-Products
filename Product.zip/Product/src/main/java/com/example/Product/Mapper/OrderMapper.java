package com.example.Product.Mapper;

import com.example.Product.DTO.OrderInputDto;
import com.example.Product.Entity.Orders;

public class OrderMapper {

    public static OrderInputDto mapToDto(Orders orders){
        OrderInputDto orderDto;
        orderDto = new OrderInputDto(orders.getOrderId(),
                        orders.getUserId(),
                        orders.getProductId());
        return orderDto;
    }

    public static Orders mapToOrder(OrderInputDto orderDto){
        Orders orders;
        orders = new Orders(orderDto.getOrderId(),
                            orderDto.getUserId(),
                            orderDto.getProductId());
        return orders;

    }

}
