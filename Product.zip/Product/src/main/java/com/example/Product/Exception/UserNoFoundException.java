package com.example.Product.Exception;

public class UserNoFoundException extends RuntimeException {
    private String message;
    public UserNoFoundException(String msg) {
            super(msg);
            this.message = msg;
        }
}
