package com.example.Product.Mapper;

import com.example.Product.DTO.ProductDto;
import com.example.Product.Entity.Products;

public class ProductMapper {

    public static ProductDto mapToDto(Products product, Long productQuantity){
        ProductDto productDto;
        productDto = new ProductDto(product.getProductId(),
                product.getProductName(),
                product.getProductCost(), productQuantity);
        return productDto;
    }

    public static Products mapToProduct(ProductDto productDto) {
        Products product;
        product = new Products(productDto.getProductId(), productDto.getProductName(), productDto.getProductCost());
        return product;
    }
}

