package com.example.Product.Controller;
import com.example.Product.DTO.ProductDto;
import com.example.Product.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/testProduct")
public class ControllerProduct {
    @Autowired
    ProductService productService;

    @PostMapping
    public ResponseEntity<ProductDto> createProduct (@RequestBody ProductDto productDto) {
        ProductDto savedProduct = productService.createProduct(productDto);
        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<ProductDto> getById(@PathVariable("id") Integer productId) {
        ProductDto productDto = productService.getProduct(Math.toIntExact(productId));
        return new ResponseEntity<>(productDto, HttpStatus.OK);

    }
}


