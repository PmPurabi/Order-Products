package com.example.Product.Service;
import com.example.Product.DTO.ProductDto;
import com.example.Product.DTO.ProductQuantityDTO;
import com.example.Product.Entity.Products;
import com.example.Product.Mapper.ProductMapper;
import com.example.Product.Repository.ProductRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService{
    @Autowired
    ProductRepo productRepo;
    @Autowired
    private RestTemplate restTemplate;
   private final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);

    @Override
    public ProductDto createProduct(ProductDto productDto) {
        Products product = ProductMapper.mapToProduct(productDto);
        Products saveProduct = productRepo.save(product);
        return ProductMapper.mapToDto(saveProduct, 0L);
    }
    @Override
    public ProductDto getProduct(Integer productId) {

        Optional<Products> product = productRepo.findById(productId);
        ProductQuantityDTO productQuantityDTO = restTemplate.getForObject("http://localhost:8085/productQuantity/{productId}",
                ProductQuantityDTO.class,productId);
        logger.info("{}", productQuantityDTO);

        return ProductMapper.mapToDto(product.get(),productQuantityDTO.getQuantity());
    }
}
