package com.example.Product.Exception;

import java.util.List;

public class ProductNotFoundException extends RuntimeException {
    private String message;
    List<Integer> proIdList;
    public ProductNotFoundException(String msg, List<Integer> productId) {
        super(msg);
        this.message = msg;
        this.proIdList = productId;
    }
    }
