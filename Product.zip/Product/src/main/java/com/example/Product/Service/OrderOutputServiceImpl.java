package com.example.Product.Service;

import com.example.Product.DTO.OrderOutputDto;
import com.example.Product.DTO.ProductDto;
import com.example.Product.DTO.UserDto;
import com.example.Product.Entity.Orders;
import com.example.Product.Entity.Products;
import com.example.Product.Entity.User;
import com.example.Product.Exception.OrderNotFoundException;
import com.example.Product.Repository.OrderRepo;
import com.example.Product.Repository.ProductRepo;
import com.example.Product.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class OrderOutputServiceImpl implements OrderOutputService {

    @Autowired
    OrderRepo orderRepo;
    @Autowired
    UserRepo userRepo;
    @Autowired
    ProductRepo productRepo;

    @Override
    public OrderOutputDto getOrderId(int orderId)
    {
        OrderOutputDto orderOutputDto = new OrderOutputDto();
        UserDto userDto1 = new UserDto(); //new UserDto
        List<ProductDto> productDtoList = new ArrayList<>(); // List of Product DTO

        Optional<Orders> findOrderId = orderRepo.findById(Long.valueOf(orderId));
        orderOutputDto.setOrderId(findOrderId.get().getOrderId());

        if(findOrderId.isPresent())
        {
            int user_id = findOrderId.get().userId; // storing the user id of the order id
            Optional<User> user = userRepo.findById(user_id);
            if (user.isPresent())
            {
                userDto1.setUserId(user.get().getUserId());
                userDto1.setName(user.get().getName());
                userDto1.setAddress(user.get().getAddress());

                orderOutputDto.setUserDto(userDto1);
            }

            List<Integer> productIdList= findOrderId.get().getProductId();

            for(Integer product_id : productIdList)
            {
                ProductDto productDto1= new ProductDto();
                Optional<Products> foundProduct = productRepo.findById(product_id);

                    productDto1.setProductId(foundProduct.get().getProductId());
                    productDto1.setProductName(foundProduct.get().getProductName());
                    productDto1.setProductCost(foundProduct.get().getProductCost());

                productDtoList.add(productDto1);
            }
            orderOutputDto.setProductDtoList(productDtoList);
        } else throw new OrderNotFoundException("Order Not Found !!!");
        return orderOutputDto;
    }
}

//create user dto, set user details to it
// orderdto have user details, userDTO user, 2. List<productDTO>
//new product dto
// add that to productlist
//set to orderdto.productList

