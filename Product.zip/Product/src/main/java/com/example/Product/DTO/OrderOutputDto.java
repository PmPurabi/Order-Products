package com.example.Product.DTO;
import com.example.Product.Entity.Products;
import com.example.Product.Entity.User;


import java.util.List;
import java.util.Optional;

public class OrderOutputDto {
    public Integer orderId;
    public UserDto userDto;
    public List<ProductDto> productDtoList;

    public OrderOutputDto() {}

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public UserDto getUserDto() {
        return userDto;
    }

    public void setUserDto(UserDto userDto) {
        this.userDto = userDto;
    }

    public List<ProductDto> getProductDtoList() {
        return productDtoList;
    }

    public void setProductDtoList(List<ProductDto> productDtoList)
    {
        this.productDtoList = productDtoList;
    }
}
