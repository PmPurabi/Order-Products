package com.example.Product.Entity;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "Product_Details")
public class Products {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "Product_Id")
    public Integer productId;
    @Column(name = "Product_Name")
    private String productName;

    @Column(name = "Price")
    private double productCost;

    public Products(){
    }
    public Products(Integer productId, String productName, double productCost) {
        this.productId = productId;
        this.productName = productName;
        this.productCost = productCost;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getProductCost() {
        return productCost;
    }

    public void setProductCost(double productCost) {
        this.productCost = productCost;
    }

    @Override
    public String toString() {
        return "Products{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", productCost=" + productCost +
                '}';
    }

//    public Products get() {
//        return null;
//    }

} // class end

