package com.example.Product.Repository;

import com.example.Product.Entity.Orders;
import com.example.Product.Entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrderRepo extends CrudRepository<Orders,Long> {


}
