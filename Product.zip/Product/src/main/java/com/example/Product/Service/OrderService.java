package com.example.Product.Service;
//import com.example.Product.DTO.OrderDetailsDto;
import com.example.Product.DTO.OrderInputDto;

public interface OrderService {

    public OrderInputDto createOrder(OrderInputDto orderDto);
    public OrderInputDto getOrder(int OrderId);
   // public OrderInputDto getOrderId(int OrderId);


}
