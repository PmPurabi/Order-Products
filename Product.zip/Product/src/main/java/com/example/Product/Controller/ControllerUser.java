package com.example.Product.Controller;

import com.example.Product.DTO.UserDto;
import com.example.Product.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/testUser") //http://localhost:8080/testUser/{id}
public class ControllerUser {
    @Autowired
    UserService userService;

    @PostMapping
    public ResponseEntity<UserDto> createUser(@RequestBody UserDto userDto) {
        UserDto savedUser = userService.createUser(userDto);
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getById(@PathVariable("id") Long userId){
        UserDto userDto = userService.getUser(Math.toIntExact(userId));
        return new ResponseEntity<>(userDto, HttpStatus.OK);
    }

}


    /*
    @RequestMapping(value = "/postUser", method = RequestMethod.POST)
    public User postUser (@RequestBody User user){return userRepo.save(user);}


    @RequestMapping(value = "/getUser/{id}", method = RequestMethod.GET)
    public Optional<User> getUser (@PathVariable("id") Long id)
    {
        return userRepo.findById(id);
    }

    @RequestMapping(value = "/putUser", method = RequestMethod.PUT)
    public User putUser (@RequestBody User user) { return userRepo.save(user);}

}


     */