package com.example.Product.Controller;

import com.example.Product.DTO.OrderInputDto;
import com.example.Product.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/testOrder")
public class ControllerOrder {
    @Autowired
    OrderService orderService;

    @PostMapping
    public ResponseEntity<OrderInputDto> createOrder(@RequestBody OrderInputDto orderDto) {
        OrderInputDto savedOrder = orderService.createOrder(orderDto);
        return new ResponseEntity<>(savedOrder, HttpStatus.CREATED);

    }

    @GetMapping("{id}")
    public ResponseEntity<OrderInputDto> getOrder (@PathVariable("id") Long orderId) {
        OrderInputDto orderInputDto = orderService.getOrder(Math.toIntExact(orderId));
        return new ResponseEntity<>(orderInputDto, HttpStatus.OK);
    }




}








