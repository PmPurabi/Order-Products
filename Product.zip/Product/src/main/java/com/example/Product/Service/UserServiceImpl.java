package com.example.Product.Service;

import com.example.Product.DTO.UserDto;
import com.example.Product.Entity.User;
import com.example.Product.Mapper.UserMapper;
import com.example.Product.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    UserRepo userRepo;

    @Override
    public UserDto createUser(UserDto userDto) {
        User user = UserMapper.mapToUser(userDto);
        User saveUser = userRepo.save(user);
        UserDto saveUserDto = UserMapper.mapToUserDto(saveUser);
        return saveUserDto;
    }

    @Override
    public UserDto getUser(int userID) {
        Optional<User> user;
        user = userRepo.findById(userID);
        User user1;
        user1 = user.get();

        return UserMapper.mapToUserDto(user1);
    }
}
