package com.example.Product.Mapper;

import com.example.Product.DTO.UserDto;
import com.example.Product.Entity.User;

public class UserMapper {
    public static UserDto mapToUserDto(User user){
        UserDto userDto;
        userDto = new UserDto(user.getUserId(),user.getName(),user.getAddress());
        return userDto;
    }

    public static User mapToUser(UserDto userDto){
        User user;
        user = new User(userDto.getUserId(),userDto.getName(),userDto.getAddress());
        return user;
    }
}
