package com.example.Product.Entity;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "Order_Details")
public class Orders
{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Integer orderId;
    public Integer userId;
    public List<Integer> productId;

    public Orders(){}
    public Orders(Integer orderId, Integer userId, List<Integer> productId) {
        this.orderId = orderId;
        this.userId = userId;
        this.productId = productId;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public List<Integer> getProductId() {
        return productId;
    }

    public void setProductId(List<Integer> productId) {
        this.productId = productId;
    }
}
//class ends
