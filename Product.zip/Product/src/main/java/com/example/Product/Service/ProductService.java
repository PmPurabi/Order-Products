package com.example.Product.Service;

import com.example.Product.DTO.ProductDto;

public interface ProductService {

    public ProductDto createProduct(ProductDto productDto);
    public ProductDto getProduct(Integer productId);
}
