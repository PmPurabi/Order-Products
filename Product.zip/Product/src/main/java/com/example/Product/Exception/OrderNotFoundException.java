package com.example.Product.Exception;

import java.util.List;

public class OrderNotFoundException extends RuntimeException{
    private String message;

    public OrderNotFoundException(String msg) {
        super(msg);
        this.message = msg;

    }
}
