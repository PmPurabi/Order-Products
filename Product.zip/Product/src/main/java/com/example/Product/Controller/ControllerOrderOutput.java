package com.example.Product.Controller;

import com.example.Product.DTO.OrderInputDto;
import com.example.Product.DTO.OrderOutputDto;
import com.example.Product.Service.OrderOutputService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/testOrderDetails")
public class ControllerOrderOutput {

    @Autowired
    OrderOutputService orderOutputService;

    @GetMapping("{id}")
    public ResponseEntity<OrderOutputDto> getOrderId (@PathVariable("id") Long orderId) {
        OrderOutputDto orderOutputDto = orderOutputService.getOrderId(Math.toIntExact(orderId));
        return new ResponseEntity<>(orderOutputDto, HttpStatus.OK);
    }
}
