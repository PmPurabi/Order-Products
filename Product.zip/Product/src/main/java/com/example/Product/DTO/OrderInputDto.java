package com.example.Product.DTO;

import java.util.List;

public class OrderInputDto
{
    private Integer orderId;
    private Integer userId;
    private List<Integer> productId;


    public OrderInputDto(Integer orderId, Integer userId, List<Integer> productId) {
        this.orderId = orderId;
        this.userId = userId;
        this.productId = productId;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public List<Integer> getProductId() {
        return productId;
    }

    public void setProductId(List<Integer> productId) {
        this.productId = productId;
    }



}