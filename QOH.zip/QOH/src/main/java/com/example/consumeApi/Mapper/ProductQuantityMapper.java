package com.example.consumeApi.Mapper;

import com.example.consumeApi.DTO.ProductQuantityDTO;
import com.example.consumeApi.Entity.ProductQuantity;

public class ProductQuantityMapper
{
    public static ProductQuantityDTO mapToDto(ProductQuantity productQuantity)
    {
        ProductQuantityDTO productQuantityDTO;
        productQuantityDTO=new ProductQuantityDTO(
                productQuantity.getProductId(),productQuantity.getQuantity());
        return productQuantityDTO;
    }

    public static ProductQuantity mapToProductQuantity(ProductQuantityDTO productQuantityDTO)
    {
        ProductQuantity productQuantity;
        productQuantity=new ProductQuantity(productQuantityDTO.getProductId(),productQuantityDTO.getQuantity());
        return productQuantity;

    }
}
