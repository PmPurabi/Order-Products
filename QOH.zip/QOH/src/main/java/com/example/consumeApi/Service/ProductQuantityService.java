package com.example.consumeApi.Service;
import com.example.consumeApi.DTO.ProductQuantityDTO;

public interface ProductQuantityService {
    public ProductQuantityDTO getProduct(Long productId);
    public ProductQuantityDTO createProduct(ProductQuantityDTO productQuantityDTO);
}
