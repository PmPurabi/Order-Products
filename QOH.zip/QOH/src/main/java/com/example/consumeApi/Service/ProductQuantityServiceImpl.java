package com.example.consumeApi.Service;

import com.example.consumeApi.DTO.ProductQuantityDTO;
import com.example.consumeApi.Entity.ProductQuantity;
import com.example.consumeApi.Mapper.ProductQuantityMapper;
import com.example.consumeApi.Repository.ProductQuantityRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ProductQuantityServiceImpl implements ProductQuantityService
{
    @Autowired
    ProductQuantityRepo productQuantityRepo;

    @Override
    public ProductQuantityDTO createProduct(ProductQuantityDTO productQuantityDTO)
    {
        ProductQuantity productQuantity = ProductQuantityMapper.mapToProductQuantity(productQuantityDTO);
        ProductQuantity save = productQuantityRepo.save(productQuantity);
        return ProductQuantityMapper.mapToDto(save);
    }
    @Override
    public ProductQuantityDTO getProduct(Long productId)
    {

        Optional<ProductQuantity> productQuantity;
        productQuantity = productQuantityRepo.findById(productId);
        return ProductQuantityMapper.mapToDto(productQuantity.get());

    }


}
