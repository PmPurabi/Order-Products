package com.example.consumeApi.Controller;


import com.example.consumeApi.DTO.ProductQuantityDTO;
import com.example.consumeApi.Service.ProductQuantityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/productQuantity")
public class ProductQuantityController {
    @Autowired
    ProductQuantityService productQuantityService;

    @PostMapping
    public ResponseEntity<ProductQuantityDTO> createProductQuantity(@RequestBody ProductQuantityDTO productQuantityDTO)
    {
        ProductQuantityDTO save = productQuantityService.createProduct(productQuantityDTO);
        return new ResponseEntity<>(save, HttpStatus.CREATED);
    }
    @GetMapping("{id}")
    public ResponseEntity<ProductQuantityDTO> getById(@PathVariable("id") Long productId){
        ProductQuantityDTO productQuantityDTO = productQuantityService.getProduct(productId);
        return new ResponseEntity<>(productQuantityDTO, HttpStatus.OK);
    }
}