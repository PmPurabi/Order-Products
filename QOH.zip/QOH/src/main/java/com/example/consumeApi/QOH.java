
//Running on 8081


package com.example.consumeApi;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QOH {

	public static void main(String[] args) {
		SpringApplication.run(QOH.class, args);
	}
}
