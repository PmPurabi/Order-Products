package com.example.consumeApi.Repository;


import com.example.consumeApi.Entity.ProductQuantity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductQuantityRepo extends CrudRepository<ProductQuantity,Long>
{
//    ProductQuantity findAllById(Long productId);
}
