package com.example.consumeApi.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Product_Quantity")
public class ProductQuantity {

    @Id
    Long productId;
    Long quantity;
    public ProductQuantity() {}

    public ProductQuantity(Long productId, Long quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getQuantity() {
        return quantity;
    }

    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "ProductQuantity{" +
                "productId=" + productId +
                ", quantity=" + quantity +
                '}';
    }
} // class ends
